/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mem;

/**
 *
 * @author Admin
 */
public class membership {
    String mem_type,nooffer,vdate;
    int amount;

    public membership() {
    }

    public membership(String mem_type, String nooffer,int amount, String vdate) {
        this.mem_type = mem_type;
        this.nooffer = nooffer;
        this.vdate = vdate;
        this.amount = amount;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getMem_type() {
        return mem_type;
    }

    public void setMem_type(String mem_type) {
        this.mem_type = mem_type;
    }

    public String getNooffer() {
        return nooffer;
    }

    public void setNooffer(String nooffer) {
        this.nooffer = nooffer;
    }

    public String getVdate() {
        return vdate;
    }

    public void setVdate(String vdate) {
        this.vdate = vdate;
    }

}
