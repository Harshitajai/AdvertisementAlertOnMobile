/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package p1;

import categories.CategoryService;
import categories.categoryDemo;
import conn.connection1;
import cust.CustomerDetail;
import cust.Customerrecord;
import cust.customer;
import insert.insertData;
import java.sql.CallableStatement;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebMethod;
import javax.jws.WebService;
import mem.membership;
import off.offerDate;
import oracle.sql.DATE;
import pack.smspack;
import payoffer.smspayoffer;
import showoffer.showoffer_customer1;
import showshop.showshopadmin;

/**
 *
 * @author user
 */
@WebService()
public class validFrom {
    @WebMethod(operationName="insertCategory")
    public boolean insertCategory(String cnm) {
      insertData in=new insertData();
      return in.insertCategory1(cnm);
     }
    
     @WebMethod(operationName="insertCity")
    public boolean insertCity(String cnm,String state) {
       insertData in=new insertData();
      return in.insertCity1(cnm, state);
     }
@WebMethod(operationName="insertfeedback1")
public boolean insertfeedback1(String name,String email,String address,String contact,String remark){
    
    insertData in=new insertData();
    return in.insertFeedback1(name, email, address, contact, remark);
}

@WebMethod(operationName="getcityid")
public List<String> getcityid(String cate){
String id="";
    try{
        Connection con=conn.connection1.getconnection();

            Statement st=con.createStatement();
            String q="select city.CITY_NAME from city,shopkeeper_detail,category where SHOPKEEPER_DETAIL.CITY_ID=city.CITY_ID and SHOPKEEPER_DETAIL.CATEGORY_ID=category.CATEGORY_ID and category.category_name='"+cate+"'";
            ResultSet rs=st.executeQuery(q);
            List<String> list=new ArrayList<String>();
            while(rs.next()){
                id=rs.getString(1);
                list.add(id);
                }

        return list;
    }catch(SQLException ex){ex.printStackTrace();
return null;
        }
    }

@WebMethod(operationName="getCategory")
public List<categoryDemo> getCategory()throws Exception
{
CategoryService cs=new CategoryService();
return cs.getCategory();
}
@WebMethod(operationName="deletecategory")
public boolean  deletecategory(String cate){
CategoryService cd=new CategoryService();
return cd.deletecate(cate);

}


@WebMethod(operationName="valid")
public boolean valid(String uid,String upass)throws Exception{
        
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            
            String q = "select * from admin where admin_name='" + uid + "' and admin_pass='" + upass + "'";
            
            ResultSet rs = st.executeQuery(q);
            
            if(rs.next())
                return true;
            else
              return false;
       }

@WebMethod(operationName="updateOffer")
public boolean  updateOffer(String pnm,String pdetail,String pdate){
    
    try {
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "update offer set offer_detail='"+pdetail+"',last_date='"+pdate+"' where product_id=(select product_id from product where product_name='"+pnm+"')";
            //System.out.println("----------------------"+q);
            st.executeQuery(q);
            con.close();
            return true;
//            Statement st1=conn.connection1.getconnection().createStatement();
//            String q1="select  product.PRODUCT_NAME,offer.OFFER_DETAIL,offer.LAST_DATE from offer,product where offer.PRODUCT_ID=product.PRODUCT_ID";
//            ResultSet rs=st1.executeQuery(q);
//            list=new ArrayList<offerDate>();
//
//          while(rs.next()){
//              System.out.println("inside loop");
//
//                offerDate od=new offerDate(rs.getString(1),rs.getString(2),rs.getString(3));
//
//                list.add(od);
//                System.out.println("----------------"+list);
//               }
//            System.out.println(list);
//
//
       } catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
         return false;
        }
//        return list;
}

@WebMethod(operationName="showoffer")
public List<offerDate> showoffer()throws Exception{
  Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q="select  product.PRODUCT_NAME,offer.OFFER_DETAIL,offer.LAST_DATE from offer,product where offer.PRODUCT_ID=product.PRODUCT_ID";
            ResultSet rs=st.executeQuery(q);
            List<offerDate> list=new ArrayList<offerDate>();
      
          while(rs.next()){
              System.out.println("inside loop");

                offerDate od=new offerDate(rs.getString(1),rs.getString(2),rs.getString(3));

                list.add(od);
                System.out.println("----------------"+list);
               }
            System.out.println(list);
            return list;
}

@WebMethod(operationName="getstate")
public List getstate()throws Exception
    {
        Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q="select state_name from state";
            ResultSet rs=st.executeQuery(q);
            List list=new ArrayList();
            while(rs.next()){
                String nm=rs.getString(1);
                list.add(nm);
            }
            System.out.println("---------------"+list);
            return list;

}

@WebMethod(operationName="getcategory1")
public List<String> getcategory1()throws Exception
    {
     Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q="select * from category";
            ResultSet rs=st.executeQuery(q);
            List<String> list=new ArrayList<String>();
            while(rs.next()){
                String nm=rs.getString(2);
                list.add(nm);
            }
           // System.out.println("---------------"+list);
            return list;


}
@WebMethod(operationName="getproduct1")
public List<String> getproduct1()throws Exception{

     Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q="select product_name from product";
            ResultSet rs=st.executeQuery(q);
            List<String> list=new ArrayList<String>();
            while(rs.next()){
                String nm=rs.getString(1);
                list.add(nm);
            }
           // System.out.println("---------------"+list);
            return list;

}

@WebMethod(operationName="insertoffer")
public boolean  insertoffer(String cate,String det,String todate,String formdate,String prod)throws Exception
{
   insertData in=new insertData();
   return in.insertOffer1(cate, det, todate, formdate, prod);
}
@WebMethod(operationName="modifycategory")
public boolean modifycategory(String nm)throws Exception{

     try {
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "update offer set category_name='"+nm+"'";
           
            st.executeQuery(q);
            con.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

@WebMethod(operationName="getcustomer")
public List getcustomer(String cate)throws Exception{
        
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "select customer.FIRSTNAME,customer.LASTNAME from customer,category where customer.CATEGORY_ID=category.CATEGORY_ID and category.category_name='" + cate + "'";
            ResultSet rs = st.executeQuery(q);
            List list=new ArrayList();
            while(rs.next()) {
                String fn=rs.getString(1);
                String ln=rs.getString(2);
                String nm=fn+" "+ln;
                list.add(nm);
            }
            return list;
        }


public List<showoffer_customer1> showoffer_customer(String cate,String city)throws Exception{
    Connection con=conn.connection1.getconnection();
    Statement st=con.createStatement();
    String q="select shopkeeper_detail.SHOP_NAME,product.PRODUCT_NAME,offer.OFFER_DETAIL,offer.LAST_DATE from shopkeeper_detail,product,offer where shopkeeper_detail.OFFER_ID=offer.OFFER_ID and SHOPKEEPER_DETAIL.CATEGORY_ID=product.CATEGORY_ID and SHOPKEEPER_DETAIL.CITY_ID=(select city_id from city where city_name='"+city+"') and SHOPKEEPER_DETAIL.CATEGORY_ID=(select category_id from category where category_name='"+cate+"')";
    ResultSet rs=st.executeQuery(q);
    List<showoffer_customer1> list=new ArrayList<showoffer_customer1>();
    while(rs.next()){
        showoffer_customer1 sw=new showoffer_customer1(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
        list.add(sw);

    }
    return list;

}

@WebMethod(operationName="getOffer")
public List<membership> getOffer(){
    List<membership> list = null;
        try {
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "select membership_type,offerno,amount,validity from membership";
            ResultSet rs = st.executeQuery(q);
             list = new ArrayList<membership>();
            while (rs.next()) {
                membership me = new membership(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4));
                list.add(me);
            }

        }
        
        catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
        }
         return list;

}

@WebMethod(operationName="deletOffer1")
public boolean  deletOffer1(String nm){
   
        try {
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "delete from offer where product_id=(select product_id from product where product_name='"+nm+"')";
            st.executeUpdate(q);
            con.close();
            return true;
              } catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
            return false;

        }
        

}

@WebMethod(operationName="getcustomerDetail")
public List<customer> getcustomerDetail(String cat){
    List<customer> list = null;
    try {

            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "select firstname,lastname,mobileno,email_id,address from customer where category_id=(select category_id from category where category_name='" + cat + "')";
            ResultSet rs = st.executeQuery(q);
            list = new ArrayList<customer>();
            while (rs.next()) {
                customer cus = new customer(rs.getString(1) + " " + rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
                list.add(cus);
            }
        }

        catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
}

public List<String> getshopname(){
    List<String> list = null ;
        try {
            list= new ArrayList<String>();
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "select shop_name from shopkeeper_detail";
            ResultSet rs = st.executeQuery(q);
           
             while(rs.next()) {
                  System.out.println("------------hello----");
                String fn = rs.getString(1);
                list.add(fn);
                }
             return list;
        }
        
        catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
}

@WebMethod(operationName="showoffer_admin")
public List<offerDate> showoffer_admin(String prod)throws Exception{
  Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q="select  product.PRODUCT_NAME,offer.OFFER_DETAIL,offer.LAST_DATE from offer,product,shopkeeper_detail where offer.PRODUCT_ID=product.PRODUCT_ID and shopkeeper_detail.shop_name='"+prod+"'";
            ResultSet rs=st.executeQuery(q);
            List<offerDate> list=new ArrayList<offerDate>();

          while(rs.next()){
              offerDate od=new offerDate(rs.getString(1),rs.getString(2),rs.getString(3));
              list.add(od);
                 }
           
            return list;
}


@WebMethod(operationName="getpurchase")
public List<smspack> getpurchase()throws Exception{
    Connection con=conn.connection1.getconnection();
    Statement st=con.createStatement();
    String q="select PACK_TYPE,AMOUNT,VALIDITY,SMSNO from PACKAGE";
    ResultSet rs=st.executeQuery(q);
    List<smspack> list=new ArrayList<smspack>();

    while(rs.next()){
        smspack sp=new smspack(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
        list.add(sp);

    }


return list;
}

@WebMethod(operationName="getpayoffer")
public List<smspayoffer> getpayoffer()throws Exception{
    Connection con=conn.connection1.getconnection();
    Statement st=con.createStatement();
    String q="select shop_name,membership.MEMBERSHIP_TYPE,membership.OFFERNO from shopkeeper_detail,membership where shopkeeper_detail.membership_id=membership.membership_id";
    ResultSet rs=st.executeQuery(q);
    List<smspayoffer> list=new ArrayList<smspayoffer>();

    while(rs.next()){
        smspayoffer pf=new smspayoffer(rs.getString(1),rs.getString(2),rs.getString(3));
        list.add(pf);
        
    }
    return list;

    }
@WebMethod(operationName="showshopkeeperadmin")
public List<showshopadmin> showshopkeeperadmin()throws Exception{
  Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q="select firstname,lastname,(select membership_type from membership where membership_id='1'),email_id,mobileno from shopkeeper_detail";
            ResultSet rs=st.executeQuery(q);
            List<showshopadmin> list=new ArrayList<showshopadmin>();

          while(rs.next()){
              System.out.println("inside loop");

                showshopadmin od=new showshopadmin(rs.getString(1)+""+rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));

                list.add(od);
                System.out.println("----------------"+list);
               }
            System.out.println(list);
            return list;
}

public String getcategory_increment()throws Exception{
    Connection con=conn.connection1.getconnection();
    Statement st=con.createStatement();
    String q="select max(category_id) from category";
    ResultSet rs=st.executeQuery(q);
    int j = 0;
    if(rs.next()){
        String i=rs.getString(1);
        j=Integer.parseInt(i);
        j=j+1;

    }
    else{
        j=1;
 }
    return ""+j;
}

@WebMethod(operationName="getcityid_increment")
public String getcityid_increment()throws Exception
    {
    Connection con=conn.connection1.getconnection();
    Statement st=con.createStatement();
    String q="select max(city_id) from citys";
    ResultSet rs=st.executeQuery(q);
    int j = 0;
    if(rs.next()){
        String i=rs.getString(1);
        j=Integer.parseInt(i);
        j=j+1;

    }
 else{
        j=1;
 }
    return ""+j;


}

@WebMethod(operationName="insertpackage")
public boolean insertpackage(String type,String amt,String nosms,String val)throws Exception{
    insertData in=new insertData();
    return in.insertpackage(type, amt, nosms, val);

}
@WebMethod(operationName="insertMembership")
public boolean insertMembership(String type,String amt,String val,String nooffer)throws Exception{

    insertData in=new insertData();
    return in.insertMembership1(type, amt, val, nooffer);
}

@WebMethod(operationName="deleteSMSpack")
public boolean deleteSMSpack(String pack)throws Exception{
    Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "delete from package where pack_id=(select pack_id from package where pack_type='"+pack+"')";
            st.executeUpdate(q);
            con.close();
            return true;
}

@WebMethod(operationName="deletemember")
public boolean  deletemember(String member)throws Exception{
    Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "delete from membership where membership_id=(select membership_id from membership where membership_type='"+member+"')";
            st.executeUpdate(q);
            con.close();
            return true;
}


@WebMethod(operationName="getproductid_increment")
public String getproductid_increment(){
    int i = 0;
        try {
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "select max(product_id) from product";
            ResultSet rs = st.executeQuery(q);
            
            if (rs.next()) {
                i = rs.getInt(1);
                i=i+1;
            }
            else{
                i=1;
 }

        } catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "" + i;
}

        @WebMethod(operationName="insertProduct")
        public boolean insertProduct(String nm,String cate){
       insertData in=new insertData();
       return in.insertProduct1(nm, cate);
        }

@WebMethod(operationName="getstateid_increment")
public String getstateid_increment()throws Exception{
    String i = null;
     int j=0;
        try {
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "select max(state_id) from state";
            ResultSet rs = st.executeQuery(q);

            if (rs.next()) {
                i = rs.getString(1);
                j=Integer.parseInt(i);
                j=j+1;
            }
            else{
                j=1;
 }

        } catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
        }
        return  ""+j;
}

@WebMethod(operationName="insertstate")
public boolean insertstate(String sname){
insertData in=new insertData();
return in.insertState1(sname);
}

@WebMethod(operationName="getcityid_All")
public List<String> getcityid_All()throws Exception{
    Connection con=conn.connection1.getconnection();
    Statement st=con.createStatement();
    String q="select city_name from city";
    ResultSet rs=st.executeQuery(q);
    List<String> list=new ArrayList<String>();
    while(rs.next()){
        String nm=rs.getString(1);
        list.add(nm);
    }
    return list;
}

@WebMethod(operationName="getlocationid_increment")
public String getlocationid_increment()throws Exception{
   String i = null;
   int j=0;
        try {
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "select max(location_id) from location";
            ResultSet rs = st.executeQuery(q);

            if (rs.next()) {
                i = rs.getString(1);
                j=Integer.parseInt(i);
                j=j+1;
            }
 else{
                j=1;
 }

        } catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
        }
        return  ""+j;
}

@WebMethod(operationName="insertCustomerRecord")
public boolean insertCustomerRecord(String fnm,String lnm,String uid,String pass,String add,String cno,String eid,String city,String cate)throws Exception
{
   insertData in=new insertData();
   return in.insertCustomer(fnm, lnm, uid, pass, add, cno, eid, city, cate);

}
@WebMethod(operationName="Gotonext")
public boolean Gotonext()
    {
        System.out.println("-----------------hello");
    return true;
}
@WebMethod(operationName="Gotonext1")
public boolean Gotonext1()
    {
        System.out.println("-----------------hello");
    return true;
}

@WebMethod(operationName="getCustomerDetail1")
public List<CustomerDetail> getCustomerDetail1()throws Exception{
    Customerrecord con= new Customerrecord();
    return con.getDeatil();
}

@WebMethod(operationName="insertShopkeeper")
public boolean insertShopkeeper(String fn,String ln,String uid,String pass,String add,String mno,String eid,String city,String cate,String lan,String lat,String s_nm,String s_add){
        insertData in=new insertData();
        return in.insertShopKeeper(fn, ln, uid, pass, add, mno, eid, city, cate, lan, lat, s_nm, s_add);
}


}







        


        

//    public static void main(String[] args) {
//        try {
//            validFrom frm = new validFrom();
//            System.out.println(frm.showoffer());
//        } catch (Exception ex) {
//            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }


