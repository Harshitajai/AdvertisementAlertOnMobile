/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package insert;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import p1.validFrom;

/**
 *
 * @author Admin
 */
public class insertData {

    public boolean insertCategory1(String nm)
    {
         try{
        Connection con=conn.connection1.getconnection();
         CallableStatement cst = con.prepareCall("{call my_category(?,?)}");
         cst.setString(1, "7");
         cst.setString(2, nm);
         cst.executeUpdate();

        con.close();
        return true;
      }
    catch(SQLException ex){
        ex.printStackTrace();
        return false;}
    }

    public boolean insertCity1(String nm,String sta)
    {
        try{

        Connection con=conn.connection1.getconnection();
         Statement st=con.createStatement();
            String s="select state_id from state where state_name='"+sta+"'";
        String st1 = null;
         ResultSet rs=st.executeQuery(s);
                while(rs.next()){
                 st1=rs.getString(1);
                break;
           }
                 CallableStatement cst = con.prepareCall("{call my_city(?,?)}");
         cst.setString(1, nm);
         cst.setString(2, st1);
         cst.executeUpdate();


        con.close();
         return true;
      }
    catch(SQLException ex){
        ex.printStackTrace();
        return false;
    }
    }

public boolean insertFeedback1(String name,String email,String address,String contact,String remark)
    {
    try{
    Connection con=conn.connection1.getconnection();
   CallableStatement cst = con.prepareCall("{call my_feedback(?,?,?,?,?)}");
         cst.setString(1, name);
         cst.setString(2, email);
          cst.setString(3, address);
           cst.setString(4, contact);
            cst.setString(5, remark);
         cst.executeUpdate();

        con.close();
        return true;
      }
    catch(SQLException ex){
        ex.printStackTrace();
        return false;
    }
}

public boolean insertOffer1(String cate,String det,String todate,String formdate,String prod)
    {
        try {
            String cat1 = null;
            int pro1 = 0;
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String cat = "select category_id from category where category_name='" + cate + "'";
            ResultSet rs1 = st.executeQuery(cat);
            System.out.println("----------------select1");
            if (rs1.next()) {
                System.out.println("------------------------hello");
                cat1 = rs1.getString(1);
            }
            String pro = "select product_id from product where product_name='" + prod + "'";
            ResultSet rs2 = st.executeQuery(pro);
            System.out.println("----------------select2");
            while (rs2.next()) {
                pro1 = rs2.getInt(1);
                System.out.println("----------------hello------------");
            }
            CallableStatement cst = con.prepareCall("{call my_offer(?,?,?,?,?)}");
            cst.setString(1, cat1);
            cst.setString(2, det);
            cst.setString(3, todate);
            cst.setString(4, formdate);
            cst.setInt(5, pro1);
            cst.executeUpdate();
            con.close();
            System.out.println("-----------------------close");
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(insertData.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
}
public boolean insertpackage(String type,String amt,String nosms,String val)
    {
        try {
            int nosms1 = Integer.parseInt(nosms);
            int amt1 = Integer.parseInt(amt);
            Connection con = conn.connection1.getconnection();
            CallableStatement cst = con.prepareCall("{call my_package(?,?,?,?)}");
            cst.setString(1, type);
            cst.setInt(2, amt1);
            cst.setInt(3, nosms1);
            cst.setString(4, val);
            cst.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(insertData.class.getName()).log(Level.SEVERE, null, ex);
            return  false;
        }
}

public boolean  insertMembership1(String type,String amt,String val,String nooffer)
{
        try {
            int amt1 = Integer.parseInt(amt);
            Connection con = conn.connection1.getconnection();
            CallableStatement cst = con.prepareCall("{call my_member(?,?,?,?)}");
            cst.setString(1, type);
            cst.setInt(2, amt1);
            cst.setString(3, val);
            cst.setString(4, nooffer);
            cst.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(insertData.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

}

public boolean insertState1(String sname)
    {
     try {
            Connection con = conn.connection1.getconnection();

            CallableStatement cst = con.prepareCall("{call my_state(?)}");

            cst.setString(1, sname);
            cst.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
}
public boolean insertCustomer(String fnm,String lnm,String uid,String pass,String add,String cno,String eid,String city,String cate)
    {
        try {
            String cid = null;
            String caid = null;
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "select city_id from city where city_name='" + city + "'";
            ResultSet rs = st.executeQuery(q);
            if (rs.next()) {
                cid = rs.getString(1);
            }
            String q1 = "select category_id from category where category_name='" + cate + "'";
            ResultSet rs1 = st.executeQuery(q1);
            if (rs1.next()) {
                caid = rs1.getString(1);
            }
            CallableStatement cst = con.prepareCall("{call my_customer(?,?,?,?,?,?,?,?,?)}");
            cst.setString(1, fnm);
            cst.setString(2, lnm);
            cst.setString(3, uid);
            cst.setString(4, pass);
            cst.setString(5, add);
            cst.setString(6, cno);
            cst.setString(7, eid);
            cst.setString(8, cid);
            cst.setString(9, caid);
            cst.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(insertData.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
}

public boolean insertShopKeeper(String fn,String ln,String uid,String pass,String add,String mno,String eid,String city,String cate,String lan,String lat,String s_nm,String s_add)
    {
    try {
            String loc = null,cnm = null,canm = null;
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q1 = "select city_id from city where city_name='" + city + "'";
            ResultSet rs1 = st.executeQuery(q1);
            if (rs1.next()) {
                cnm = rs1.getString(1);
            }
            String q2 = "select category_id from category where category_name='" + cate + "'";
            ResultSet rs2 = st.executeQuery(q2);
            if (rs2.next()) {
                canm = rs2.getString(1);
            }
            String q3 = "select location_id from location where longitude='"+lan+"' and latitude='"+lat+"'";
            ResultSet rs3 = st.executeQuery(q3);
            if (rs3.next()) {
               loc = rs3.getString(1);
            }
             CallableStatement cst = con.prepareCall("{call my_shopkeeper(?,?,?,?,?,?,?,?,?,?,?,?)}");
         cst.setString(1, fn);
         cst.setString(2, ln);
         cst.setString(3,uid);
         cst.setString(4, pass);
         cst.setString(5, add);
         cst.setString(6, mno);
         cst.setString(7, eid);
         cst.setString(8, cnm);
         cst.setString(9, canm);
         cst.setString(10, loc);
         cst.setString(11, s_nm);
         cst.setString(12, s_add);
   cst.executeUpdate();
   return true;

        } catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
}

public boolean insertProduct1(String nm,String cate)
    {
     try {
            Connection con = conn.connection1.getconnection();
            String q1="select category_id from category where category_name='"+cate+"'";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(q1);
            String a = null;
            if(rs.next()){
                a=rs.getString(1);
            }
            CallableStatement cst = con.prepareCall("{call my_product(?,?)}");
            cst.setString(1, nm);
            cst.setString(2, a);
            cst.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
}


}
