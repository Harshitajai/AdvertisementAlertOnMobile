/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cust;

/**
 *
 * @author Admin
 */
public class customer {
    String cnm,cno,ceid,cadd;


    public customer() {
    }

    public customer(String cnm, String cno, String ceid, String cadd) {
        this.cnm = cnm;
        this.cno = cno;
        this.ceid = ceid;
        this.cadd = cadd;
    }

    public String getCadd() {
        return cadd;
    }

    public void setCadd(String cadd) {
        this.cadd = cadd;
    }

    public String getCeid() {
        return ceid;
    }

    public void setCeid(String ceid) {
        this.ceid = ceid;
    }

    public String getCnm() {
        return cnm;
    }

    public void setCnm(String cnm) {
        this.cnm = cnm;
    }

    public String getCno() {
        return cno;
    }

    public void setCno(String cno) {
        this.cno = cno;
    }


}
