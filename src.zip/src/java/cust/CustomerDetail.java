/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cust;

/**
 *
 * @author Admin
 */
public class CustomerDetail {

    String fnm,lnm,user_id,pass,add,mno,e_id,city,cate;

    public CustomerDetail(String fnm, String lnm, String user_id, String pass, String add, String mno, String e_id, String city, String cate) {
        this.fnm = fnm;
        this.lnm = lnm;
        this.user_id = user_id;
        this.pass = pass;
        this.add = add;
        this.mno = mno;
        this.e_id = e_id;
        this.city = city;
        this.cate = cate;
    }

    public CustomerDetail() {
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public String getCate() {
        return cate;
    }

    public void setCate(String cate) {
        this.cate = cate;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getE_id() {
        return e_id;
    }

    public void setE_id(String e_id) {
        this.e_id = e_id;
    }

    public String getFnm() {
        return fnm;
    }

    public void setFnm(String fnm) {
        this.fnm = fnm;
    }

    public String getLnm() {
        return lnm;
    }

    public void setLnm(String lnm) {
        this.lnm = lnm;
    }

    public String getMno() {
        return mno;
    }

    public void setMno(String mno) {
        this.mno = mno;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    @Override
    public String toString() {
        return "CustomerDetail{" + "fnm=" + fnm + "lnm=" + lnm + "user_id=" + user_id + "pass=" + pass + "add=" + add + "mno=" + mno + "e_id=" + e_id + "city=" + city + "cate=" + cate + '}';
    }
    

}
