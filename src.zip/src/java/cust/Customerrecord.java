/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cust;

import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Admin
 */
public class Customerrecord {


    public List<CustomerDetail> getDeatil()throws Exception{
        List<CustomerDetail> list = new ArrayList<CustomerDetail>();
        

            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "select * from customer";
            ResultSet rs = st.executeQuery(q);
            String canm=null;
            String cnm=null;
            while(rs.next())
            {
                String r=rs.getString(9);
                String n=rs.getString(10);
                String eid=rs.getString(8);
                String mno=rs.getString(7);
                String add=rs.getString(6);
                String pass=rs.getString(5);
                String uid=rs.getString(4);
                String ln=rs.getString(3);
                String fn=rs.getString(2);
                String id=rs.getString(1);
               
                String q1="select city_name from city where city_id='"+r+"'";
                Statement st1 = con.createStatement();
                ResultSet rs1=st1.executeQuery(q1);
                if(rs1.next()){

                    cnm=rs1.getString(1);
                    System.out.println("--------hello1"+cnm);
                }
                String q2="select category_name from category where category_id='"+n+"'";
                Statement st2 = con.createStatement();
                ResultSet rs2=st2.executeQuery(q2);
                if(rs2.next()){

                    canm=rs2.getString(1);
                    System.out.println("--------hello1"+canm);
                }

                CustomerDetail cu=new CustomerDetail(fn,ln,uid,pass,add,mno,eid,cnm,canm);
                //System.out.println("--"+rs.getString(2)+"--"+rs.getString(3)+"--"+rs.getString(4)+"--"+rs.getString(5)+"--"+rs.getString(6)+"--"+rs.getString(7)+"--"+rs.getString(8)+"--"+cnm+"---"+canm);
                list.add(cu);
//                System.out.println("@@@@@@@@@@@@@@@@@@@ "+list);
                }
                System.out.println("__________________"+list);
            
                return list;
    }

}
