/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package showshop;

/**
 *
 * @author rakesh
 */
public class showshopadmin {
    String snm,smem,seid,scno;

    public showshopadmin() {
    }

    public String getScno() {
        return scno;
    }

    public void setScno(String scno) {
        this.scno = scno;
    }

    public String getSeid() {
        return seid;
    }

    public void setSeid(String seid) {
        this.seid = seid;
    }

    public String getSmem() {
        return smem;
    }

    public void setSmem(String smem) {
        this.smem = smem;
    }

    public String getSnm() {
        return snm;
    }

    public void setSnm(String snm) {
        this.snm = snm;
    }

    public showshopadmin(String snm, String smem, String seid, String scno) {
        this.snm = snm;
        this.smem = smem;
        this.seid = seid;
        this.scno = scno;
    }

}
