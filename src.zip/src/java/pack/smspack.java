/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pack;

/**
 *
 * @author Admin
 */
public class smspack {
    String ptype,amt,val,smsno;

    public smspack(String ptype, String amt, String val, String smsno) {
        this.ptype = ptype;
        this.amt = amt;
        this.val = val;
        this.smsno = smsno;
    }

    public smspack() {
    }

    public String getAmt() {
        return amt;
    }

    public void setAmt(String amt) {
        this.amt = amt;
    }

    public String getPtype() {
        return ptype;
    }

    public void setPtype(String ptype) {
        this.ptype = ptype;
    }

    public String getSmsno() {
        return smsno;
    }

    public void setSmsno(String smsno) {
        this.smsno = smsno;
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

}
