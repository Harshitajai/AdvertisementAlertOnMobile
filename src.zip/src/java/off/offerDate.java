/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package off;

import java.io.Serializable;

/**
 *
 * @author user
 */
public class offerDate  implements Serializable{
    String pnm;
    String pdetail;
    String pddate;

    public offerDate() {
    }
    

    public offerDate(String pnm, String pdetail, String pdate) {
        this.pnm = pnm;
        this.pdetail = pdetail;
        this.pddate = pdate;
    }

    public String getPddate() {
        return pddate;
    }

    public void setPddate(String pddate) {
        this.pddate = pddate;
    }

    public String getPdetail() {
        return pdetail;
    }

    public void setPdetail(String pdetail) {
        this.pdetail = pdetail;
    }

    public String getPnm() {
        return pnm;
    }

    public void setPnm(String pnm) {
        this.pnm = pnm;
    }

    @Override
    public String toString() {
        return pnm+"  "+pddate;
    }



}
