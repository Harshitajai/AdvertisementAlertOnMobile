/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class connection1 {
    static Connection con=null;

    static
    {
        try
        {
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl2","scott","tiger");
            System.out.println("------------------"+con);

        }catch(ClassNotFoundException e){}catch(SQLException e){e.printStackTrace();}

    }
    public static Connection getconnection()
    {
        try {
            if (con.isClosed()) {
                con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl2s", "scott", "tiger");
            }

        }

        //    public static Connection getconnection() throws SQLException{
        //        if(con.isClosed())
        //        {
        //        try {
        //
        //           con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "scott", "tiger");
        //        } catch (Exception ex) {
        //        ex.printStackTrace();
        //        }}
        //        return con;
        //
        //    }
        catch (SQLException ex) {
            Logger.getLogger(connection1.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }

}
