/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package payoffer;

/**
 *
 * @author Admin
 */
public class smspayoffer {
    String snm,mem,toffer;

    public smspayoffer(String snm, String mem, String toffer) {
        this.snm = snm;
        this.mem = mem;
        this.toffer = toffer;
    }
      public String getSnm() {
        return snm;
    }

    public void setSnm(String snm) {
        this.snm = snm;
    }
    public smspayoffer() {
    }
    

    public String getMem() {
        return mem;
    }

    public void setMem(String mem) {
        this.mem = mem;
    }

  

    public String getToffer() {
        return toffer;
    }

    public void setToffer(String toffer) {
        this.toffer = toffer;
    }


}
