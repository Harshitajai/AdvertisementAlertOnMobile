/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package categories;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import p1.validFrom;

/**
 *
 * @author Admin
 */
public class CategoryService {

   public boolean deletecate(String cate){
    List list=new ArrayList<categoryDemo>();
        try {
            Connection con = conn.connection1.getconnection();
            Statement st = con.createStatement();
            String q = "delete from category where category_name='" + cate + "'";
            st.executeUpdate(q);
            con.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(validFrom.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
public List<categoryDemo> getCategory()throws Exception{

 Connection con=conn.connection1.getconnection();
    Statement st=con.createStatement();
    String q="select category_name from category";
    ResultSet rs=st.executeQuery(q);
    List list=new ArrayList<categoryDemo>();
    while(rs.next()){
       categoryDemo c=new categoryDemo(rs.getString(1));
        list.add(c);
    }
    return list;
}



}
