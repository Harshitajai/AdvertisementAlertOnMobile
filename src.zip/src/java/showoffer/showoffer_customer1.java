/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package showoffer;

/**
 *
 * @author Admin
 */
public class showoffer_customer1 {
    String sname,pname,detail,ldate;

    public showoffer_customer1(String sname, String pname, String detail, String ldate) {
        this.sname = sname;
        this.pname = pname;
        this.detail = detail;
        this.ldate = ldate;
    }

    public showoffer_customer1() {
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getLdate() {
        return ldate;
    }

    public void setLdate(String ldate) {
        this.ldate = ldate;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

}
