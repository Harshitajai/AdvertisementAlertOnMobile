package com.activity;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Randemly extends Activity {
	private static final int NOTIFY_ME_ID=1337;
	private Timer timer=new Timer();
	private int count=0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.notify);
		Button btn=(Button) findViewById(R.id.notify1);
		btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				TimerTask task=new TimerTask() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						notifyMe();
					}
				};
				timer.schedule(task, 5000);
			}
		});
		btn=(Button) findViewById(R.id.notify2);
		btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				NotificationManager mgr=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
				mgr.cancel(NOTIFY_ME_ID);
			}
		});
	}
	     private void notifyMe(){
	    	 final NotificationManager mgr=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
	    	 Notification note=new Notification(R.drawable.icon,"Status Message", System.currentTimeMillis());
	    	 PendingIntent i=PendingIntent.getActivity(this, 0, new Intent(this,NearShop.class), 0);
	    	 note.setLatestEventInfo(this, "Notification Title", "This is the notification message", i);
	    	 
	    	 note.number=+count;
	    	 mgr.notify(NOTIFY_ME_ID,note);
	     }
		
	}


