package com.activity;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class NearShop extends  Activity{
	ListView lst;
    
	LocationManager lm;
 
	double lat, lng;
	 String str="";
	  String s1,s2;
	  int a1,a2;
	  Button btn;
	  TextView T;
	  ArrayList<String> list1=new ArrayList<String>();
		ArrayList<String> list2=new ArrayList<String>();
	
		@Override
	    protected void onCreate(Bundle savedInstanceState) {
	    	// TODO Auto-generated method stub
	    	super.onCreate(savedInstanceState);
	   setContentView(R.layout.nearshopgps);
	    	btn=(Button) findViewById(R.id.nearbtn);
	         lst=(ListView) findViewById(R.id.nearlist);
	         T=(TextView) findViewById(R.id.nearofftext);
	      // lst.setBackgroundColor(444488);
	         
	         btn.setOnClickListener(new OnClickListener() {
	     		
	     		@Override
	     		public void onClick(View v) {
	     			// TODO Auto-generated method stub
	     		//	T.setText("lat="+lat+"lng="+lng);
	     			lst.setEnabled(true);
	     			try{
	     		    	 DefaultHttpClient client=new DefaultHttpClient();
	     		    	 HttpGet get=new HttpGet("http://10.0.0.1:8080/AlertNetProject/CityServlet?lati="+lat+"&longi="+lng);
	     		    	 HttpResponse response=client.execute(get);
	     		    	 HttpEntity resent=response.getEntity();
	     		    	 InputStream in=resent.getContent();
	     					InputStreamReader isr=new InputStreamReader(in);
	     					 BufferedReader br=new BufferedReader(isr);
	     					 
	     					 while(true){
	     						 String s1=br.readLine();
	     			    		 if(s1==null)break;
	     			    		 str+=s1;
	     			    	 }
	     					list1.clear();
	     					list2.clear();
	     					 
	     				//	 System.out.print(str);
	     				//	 Log.v(str, "message");
	     					 Toast.makeText(NearShop.this,"----w---"+str,Toast.LENGTH_SHORT).show();
	     					 while(str.length()!=0){
	     						 a1=str.indexOf(",");
	     						a2=str.indexOf("@");
	     						s1=str.substring(0,a1);
	     						s2=str.substring(a1+1,a2);
	     						str=str.substring(a2+1);
	     						
	     						list1.add(s1);
	     					
	     						list2.add(s2);
	     						Log.v(list1+"@@@"+list2, "yaa");
	     					 }
	     				//	 Toast.makeText(SearchCity.this,"--"+list1+"---"+list2,Toast.LENGTH_SHORT);
	     					 ArrayAdapter<String> adp=new ArrayAdapter<String>(NearShop.this,android.R.layout.simple_dropdown_item_1line,list1);
	     					 lst.setAdapter(adp);
	     			 }catch(Exception ex){
	     			    ex.printStackTrace();	
	     			   	  }

	     		}
	     	});
	         lm = (LocationManager) getSystemService(LOCATION_SERVICE);
	         
	         lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 6000, 20, new LocationListener() {
	 		
	 			@Override
	 			public void onStatusChanged(String provider, int status, Bundle extras) {
	 				// TODO Auto-generated method stub
	 				Log.v("","On Status Changed");
	 			}
	 			
	 			@Override
	 			public void onProviderEnabled(String provider) {
	 				// TODO Auto-generated method stub
	 				Log.v("","On Provider Enabled");
	 				
	 			}
	 			
	 			@Override
	 			public void onProviderDisabled(String provider) {
	 				// TODO Auto-generated method stub
	 				Log.v("","On Provider Disabled");
	 				
	 			}
	 			
	 			@Override
	 			public void onLocationChanged(Location location) {
	 				// TODO Auto-generated method stub
	 				Log.v("","On Location Changed");
	 				lat = location.getLatitude();
	 				lng = location.getLongitude();
	 			//	lat=lat+0.550;
	 			//	lng=lng+0.550;
	 				
	 				
	 			}
	 		});
	        
	     
	    	 				 lst.setOnItemClickListener(new OnItemClickListener() {

						@Override
						public void onItemClick(AdapterView<?> arg0, View arg1,
								int arg2, long arg3) {
							String a=list2.get(arg2);
							 Toast.makeText(NearShop.this,"$$"+a,Toast.LENGTH_SHORT);
							// TODO Auto-generated method stub
							String str=(String)lst.getItemAtPosition(arg2);
							Intent in = new Intent(NearShop.this,Alertnearshop.class);
							in.putExtra("id",a);
							startActivity(in);
						}
					});
	    	 
	    	 // ArrayAdapter<String> adp=new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,list);
	    	// lst.setAdapter(adp);
	    //	 Log.v("",""+list.length);
	    	 
//	    	 lst.setOnItemClickListener(new OnItemClickListener() {
//
//				@Override
//				public void onItemClick(AdapterView<?> arg0, View arg1,
//						int arg2, long arg3) {
//					// TODO Auto-generated method stub
//					String str=(String)lst.getItemAtPosition(arg2);
//		
//					Intent in = new Intent(NearShop.this,Alertnearshop.class);
//					in.putExtra("offer",str);
//					startActivity(in);
//				}
//			});
	  
	   	 
	   	}
		
		@Override
		public boolean onCreateOptionsMenu(Menu menu) {
			// TODO Auto-generated method stub
			MenuItem send=menu.add(0,1,0,"Send");
			MenuItem back=menu.add(0,2,1,"Back");
			
			send.setOnMenuItemClickListener(new OnMenuItemClickListener() {
				
				@Override
				public boolean onMenuItemClick(MenuItem item) {
					
					// TODO Auto-generated method stub
					
					return false;
				}
			});
			
			back.setOnMenuItemClickListener(new OnMenuItemClickListener() {
				
				@Override
				public boolean onMenuItemClick(MenuItem item) {
					// TODO Auto-generated method stub
					return false;
				}
			});
			
			return super.onCreateOptionsMenu(menu);
		}
    
}
