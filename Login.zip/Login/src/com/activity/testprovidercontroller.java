package com.activity;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;

public class testprovidercontroller extends Activity {
    LocationManager lm;  
	@Override
       
    protected void onCreate(Bundle savedInstanceState) {
    	// TODO Auto-generated method stub
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.gps);
    	String context=Context.LOCATION_SERVICE;
    	lm=(LocationManager) getSystemService(context);
    	testproviders();
    }
	public void testproviders(){
		TextView tv=(TextView) findViewById(R.id.mylocation);
		StringBuilder sb=new StringBuilder("Enable Provider");
		List<String> providers=lm.getProviders(true);
		for(String provider:providers){
			lm.requestLocationUpdates(provider, 1000, 0, new LocationListener() {
				
				@Override
				public void onStatusChanged(String provider, int status, Bundle extras) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void onProviderEnabled(String provider) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void onProviderDisabled(String provider) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void onLocationChanged(Location location) {
					// TODO Auto-generated method stub
					
				}
			});
			sb.append("\n").append(provider).append(":");
			Location location=lm.getLastKnownLocation(provider);
			if(location!=null){
				double lat=location.getLatitude();
				double lng=location.getLongitude();
				sb.append(lat).append(", ").append(lng);
			}else{
				sb.append("No Location");
				
			}
		}
		tv.setText(sb);
	}
}
