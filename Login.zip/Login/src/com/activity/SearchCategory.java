package com.activity;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;

public class SearchCategory extends Activity {
	
	  TextView showcategory;
	  Spinner spcategory;
	 ListView lst;
	  String list[];
	  String str="";
	  String s1,s2;
	  int a1,a2;
	 
	  ArrayList<String> list1=new ArrayList<String>();
		ArrayList<String> list2=new ArrayList<String>();
		@Override
	protected void onCreate(Bundle savedInstanceState) {
			
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.searchcategory);
		showcategory=(TextView) findViewById(R.id.scategoryname);
		spcategory=(Spinner) findViewById(R.id.Spinner_cate);
		
		lst=(ListView) findViewById(R.id.showcategory);
		
		try{
			 DefaultHttpClient client=new DefaultHttpClient();
			 
			 HttpPost post=new HttpPost("http://10.0.0.1:8080/AlertNetProject/SearchCategory");
			 HttpResponse response=client.execute(post);
			 HttpEntity resent=response.getEntity();
			 InputStream in=resent.getContent();
			
			 String str="Category,";
			 while(true){
				 int ch=in.read();
				 if(ch==-1)break;
				 str+=(char)ch;
			 }
		//	 Toast.makeText(SearchCategory.this,"abc",Toast.LENGTH_LONG).show();
			 String list[]=str.split(",");
			 for(int i=0;i<list.length;i++){
				 list[i]=list[i].trim();
			 }
			
		//	 Toast.makeText(SearchCategory.this,""+list.length,Toast.LENGTH_LONG).show();
		//	 Toast.makeText(SearchCategory.this,"abc",Toast.LENGTH_LONG).show();
			 ArrayAdapter<String> aa=new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,list);
			 spcategory.setAdapter(aa);
			}catch(Exception ex){
				ex.printStackTrace();
			}
			
		spcategory.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				String s=(String) spcategory.getItemAtPosition(arg2);
				//Toast.makeText(SearchCity.this,s,Toast.LENGTH_LONG).show();
				try{
				DefaultHttpClient client=new DefaultHttpClient();
				 HttpGet get=new HttpGet("http://10.0.0.1:8080/AlertNetProject/showoffercategory?offer="+s);
				 HttpResponse response=client.execute(get);
				 HttpEntity resent=response.getEntity();
				 InputStream in=resent.getContent();
				InputStreamReader isr=new InputStreamReader(in);
				 BufferedReader br=new BufferedReader(isr);
				 
				 while(true){
					 String s1=br.readLine();
		    		 if(s1==null)break;
		    		 str+=s1;
		    	 }
				list1.clear();
				list2.clear();
				 
			//	 System.out.print(str);
			//	 Log.v(str, "message");
				// Toast.makeText(SearchCity.this,"----w---"+str,Toast.LENGTH_SHORT).show();
				 while(str.length()!=0){
					 a1=str.indexOf(",");
					a2=str.indexOf("@");
					s1=str.substring(0,a1);
					s2=str.substring(a1+1,a2);
					str=str.substring(a2+1);
					
					list1.add(s1);
				
					list2.add(s2);
					Log.v(list1+"@@@"+list2, "yaa");
				 }
			//	 Toast.makeText(SearchCity.this,"--"+list1+"---"+list2,Toast.LENGTH_SHORT);
				 ArrayAdapter<String> adp=new ArrayAdapter<String>(SearchCategory.this,android.R.layout.simple_dropdown_item_1line,list1);
				 lst.setAdapter(adp);
				 lst.setOnItemClickListener(new OnItemClickListener() {

						@Override
						public void onItemClick(AdapterView<?> arg0, View arg1,
								int arg2, long arg3) {
							String a=list2.get(arg2);
							 //Toast.makeText(SearchCategory.this,"$$"+a,Toast.LENGTH_SHORT);
							// TODO Auto-generated method stub
							String str=(String)lst.getItemAtPosition(arg2);
							Intent in = new Intent(SearchCategory.this,Alertnearshop.class);
							in.putExtra("id",a);
							startActivity(in);
						}
					});
				}catch(Exception ex){
					ex.printStackTrace();
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
//		ArrayAdapter<String> aa=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,str);
//		aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
		
	}
}
