package com.activity;

import android.app.Activity;

public class NotifyMessage extends Activity {
	  
	

}
