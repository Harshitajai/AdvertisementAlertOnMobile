package com.activity;

import java.util.ArrayList;

import org.apache.http.io.SessionInputBuffer;

//import com.data.StudentDataAdapter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethod.SessionCallback;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class list1 extends Activity {
	ListView	lst;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list1);
	    lst = (ListView) findViewById(R.id.lv);
        String op[] = {"Offer By Near Shop","Offer By Randemly","Offer By Search","Logout" };
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,op);
        lst.setAdapter(adapter);
        
        lst.setOnItemClickListener(new OnItemClickListener() {

			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				if(arg2==0) {
					Intent in = new Intent(list1.this,NearShop.class);
					startActivity(in);
			}
				if(arg2==1) {
					Intent in = new Intent(list1.this,Randemly.class);
					startActivity(in);
				}
				if(arg2==2) {
					Intent in = new Intent(list1.this,SearchOption.class);
					startActivity(in);
				}
				if(arg2==3) {
					
					Intent in = new Intent(list1.this,wellcome.class);
					startActivity(in);
					
				}
			}
		});
    }
	}


