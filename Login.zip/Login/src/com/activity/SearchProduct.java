package com.activity;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;

public class SearchProduct extends Activity {
	  TextView showcategoryp,spproductname;
	  Spinner spcategoryp,spproductp;
	  ListView lst;
	  String str2="";
	  String s1,s2;
	  int a1,a2;
	  ArrayList<String> list1=new ArrayList<String>();
		ArrayList<String> list2=new ArrayList<String>();

		@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.searchproduct);
		showcategoryp=(TextView) findViewById(R.id.scategorynamep);
		spproductname=(TextView) findViewById(R.id.sproductname);
		spcategoryp=(Spinner) findViewById(R.id.Spineercategoryp);
		spproductp=(Spinner) findViewById(R.id.Spinnerproduct);
		lst=(ListView) findViewById(R.id.showproduct);
		
		try{
			 DefaultHttpClient client=new DefaultHttpClient();
			 
			 HttpPost post=new HttpPost("http://10.0.0.1:8080/AlertNetProject/SearchCategory");
			 HttpResponse response=client.execute(post);
			 HttpEntity resent=response.getEntity();
			 InputStream in=resent.getContent();
			
			 String str="Category,";
			 while(true){
				 int ch=in.read();
				 if(ch==-1)break;
				 str+=(char)ch;
			 }
			 String list[]=str.split(",");
			 for(int i=0;i<list.length;i++){
				 list[i]=list[i].trim();
			 }
			 Toast.makeText(SearchProduct.this,""+list.length,Toast.LENGTH_LONG).show();
		
			 ArrayAdapter<String> aa=new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,list);
			 spcategoryp.setAdapter(aa);
			 spcategoryp.setOnItemSelectedListener(new OnItemSelectedListener() {

					@Override
					public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
							long arg3) {
						// TODO Auto-generated method stub
						String s=(String) spcategoryp.getItemAtPosition(arg2);
						//Toast.makeText(SearchCity.this,s,Toast.LENGTH_LONG).show();
						try{
						DefaultHttpClient client=new DefaultHttpClient();
						 HttpGet get=new HttpGet("http://10.0.0.1:8080/AlertNetProject/showproductname?name="+s);
						 HttpResponse response=client.execute(get);
						 HttpEntity resent=response.getEntity();
						 InputStream in=resent.getContent();
						 
						 String str1="ProductName,";
						 while(true){
				    		 int ch=in.read();
				    		 if(ch==-1)break;
				    		 str1+=(char)ch;
				    	 }
						 String list[]=str1.split(",");
						 for(int i=0;i<list.length;i++){
							 list[i]=list[i].trim();
						 }
						 list1.clear();
							list2.clear();
						 ArrayAdapter<String> adp=new ArrayAdapter<String>(SearchProduct.this,android.R.layout.simple_dropdown_item_1line,list);
						 spproductp.setAdapter(adp);
						spproductp.setOnItemSelectedListener(new OnItemSelectedListener() {

							@Override
							public void onItemSelected(AdapterView<?> arg0, View arg1,
									int arg2, long arg3) {
								
								// TODO Auto-generated method stub
								String p=(String) spproductp.getItemAtPosition(arg2);
								
								try{
									DefaultHttpClient client=new DefaultHttpClient();
									 HttpGet get=new HttpGet("http://10.0.0.1:8080/AlertNetProject/showOfferProduct?offer="+p);
									 HttpResponse response=client.execute(get);
									 HttpEntity resent=response.getEntity();
									 InputStream in=resent.getContent();
										InputStreamReader isr=new InputStreamReader(in);
										 BufferedReader br=new BufferedReader(isr);
										 
										 while(true){
											 String s1=br.readLine();
								    		 if(s1==null)break;
								    		 str2+=s1;
								    	 }
										
										 
									//	 System.out.print(str);
									//	 Log.v(str, "message");
										 Toast.makeText(SearchProduct.this,"----w---"+str2,Toast.LENGTH_SHORT).show();
										 while(str2.length()!=0){
											 a1=str2.indexOf(",");
											a2=str2.indexOf("@");
											s1=str2.substring(0,a1);
											s2=str2.substring(a1+1,a2);
											str2=str2.substring(a2+1);
											
											list1.add(s1);
										
											list2.add(s2);
											Log.v(list1+"@@@"+list2, "yaa");
										 }
									 ArrayAdapter<String> adp=new ArrayAdapter<String>(SearchProduct.this,android.R.layout.simple_dropdown_item_1line,list1);
									 lst.setAdapter(adp);
									 lst.setOnItemClickListener(new OnItemClickListener() {

										@Override
										public void onItemClick(AdapterView<?> arg0,
												View arg1, int arg2, long arg3) {
											
											// TODO Auto-generated method stub
											
											String a=list2.get(arg2);
											 Toast.makeText(SearchProduct.this,"$$"+a,Toast.LENGTH_SHORT);
											// TODO Auto-generated method stub
											String str=(String)lst.getItemAtPosition(arg2);
											Intent in = new Intent(SearchProduct.this,Alertnearshop.class);
											in.putExtra("id",a);
											startActivity(in);
										}
									});

									 
								}catch(Exception ex){
									ex.printStackTrace();
								}
							}

							@Override
							public void onNothingSelected(AdapterView<?> arg0) {
								// TODO Auto-generated method stub
								
							}
						});
						}catch(Exception ex){
							ex.printStackTrace();
						}
					}

					@Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						
					}
				});
			 
			}catch(Exception ex){
				ex.printStackTrace();
			}
			
		//		ArrayAdapter<String> aa=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,str);
//		aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
		
	}
}
