package com.activity;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;

import android.widget.TextView;
import android.widget.Toast;


public class Alertnearshop extends Activity {
	
	TextView msg;
	Builder builder;
	 
	@Override
    protected void onCreate(Bundle savedInstanceState) {
    	// TODO Auto-generated method stub
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.nearshop);
    	msg=(TextView) findViewById(R.id.TextView01);
    	Bundle ex=getIntent().getExtras();
    	String s=ex.getString("id");
    //	String list[]=ex.getStringArray("list");
    	//Toast.makeText(this,list[0]+","+list[1],Toast.LENGTH_LONG).show();
      
    	
    	 
    	 try{
    	 DefaultHttpClient client=new DefaultHttpClient();
    	 HttpGet get=new HttpGet("http://10.0.0.1:8080/AlertNetProject/AlertDetail?offer="+s);
    	 HttpResponse response=client.execute(get);
    	 HttpEntity resent=response.getEntity();
    	 InputStream in=resent.getContent();
    	 InputStreamReader isr=new InputStreamReader(in);
		 BufferedReader br=new BufferedReader(isr);
		
    	
    	String str="";
    	 while(true){
    		 String s1=br.readLine();
    		 if(s1==null)break;
    		 str+=s1;    	
    		 }
    	 Toast.makeText(Alertnearshop.this,"@@"+str,Toast.LENGTH_SHORT);
    	
    	 AlertDialog.Builder builder=new AlertDialog.Builder(this);
    	 builder.setMessage("Alert Message");
    	 builder.setTitle("Offer Detail");
    	 builder.setPositiveButton("ok", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				dialog.cancel();
			}
		});
    	 AlertDialog alert= builder.create();
         alert.show();  
         
    	 int a=str.indexOf(",");
    	
    	 int b=str.indexOf("@");
    	 int c=str.indexOf("$");
    	 
    	 String detail=str.substring(0, a-1);
    	 Toast.makeText(Alertnearshop.this,""+detail,Toast.LENGTH_LONG).show();
    	 String snm=str.substring(a+1, b-1);
    	 String sadd=str.substring(b+1,c-1);
    	 String cno=str.substring(c+1);
    	
    	 msg.setText("This Shop Name"+snm+",Address of"+sadd+",Contact No"+cno+",Detail"+detail);
    	 
    	// Log.v(s,"the");
    //	 Toast.makeText(this,s,Toast.LENGTH_LONG).show();
    	
    	
   	  }catch(Exception e){
    e.printStackTrace();	
   	  }
   	
	
 
	 
	 
 }
   
}
