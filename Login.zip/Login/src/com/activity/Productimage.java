package com.activity;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class Productimage extends Activity {
	
	Intent in;
	TextView tv1;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	    setContentView(R.layout.productimage);
	  
		 tv1 = (TextView) findViewById(R.id.imgv1);
		 new MyThread().start();
       
	
	}
	 class MyThread extends Thread {
	    	public void run() {
	         
	            	try {
	    				Thread.sleep(3000);
	    				stop();
	            		in = new Intent(Productimage.this,list1.class);
	    				startActivity(in);
	    			} catch (Exception ex) {
	    				// TODO Auto-generated catch block
	    				ex.printStackTrace();
	    			}
	            
	        //    Toast.makeText(getApplicationContext(),"Time Completed", Toast.LENGTH_SHORT).show();
	 }
	 }


}
