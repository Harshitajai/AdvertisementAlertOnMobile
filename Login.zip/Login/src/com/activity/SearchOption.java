package com.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class SearchOption extends Activity {
	ListView	lst;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list1);
	    lst = (ListView) findViewById(R.id.lv);
        String op[] = {"Search By City","Search By Category","Search By Product"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,op);
        lst.setAdapter(adapter);
        
        lst.setOnItemClickListener(new OnItemClickListener() {

			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				if(arg2==0) {
					Intent in = new Intent(SearchOption.this,SearchCity.class);
					startActivity(in);
			}
				if(arg2==1) {
					Intent in = new Intent(SearchOption.this,SearchCategory.class);
					startActivity(in);
				}
				if(arg2==2) {
					Intent in = new Intent(SearchOption.this,SearchProduct.class);
					startActivity(in);
				}
				
			}
		});
    }

}
